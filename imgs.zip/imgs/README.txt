Acesta este Cv-ul meu. Aveti in codul scris /* */ sectiuni de genul pentru intelegerea codului mai usor.
Web-siteul este responsive si gata de functionare o zi buna.
